label_color_map = [
    (0, 0, 0),  # 0: background → black
    (255, 0, 0),  # 1: coin type A → red
    (0, 255, 0),  # 2: coin type B → green
    (0, 0, 255),  # 3: coin type C → blue
    (255, 255, 0),  # 4: coin type D → yellow
    (255, 0, 255),  # 5: coin type E → magenta
    (0, 255, 255),  # 6: coin type F → cyan
    (255, 165, 0),  # 7: coin type G → orange
    # …add more as needed
]
